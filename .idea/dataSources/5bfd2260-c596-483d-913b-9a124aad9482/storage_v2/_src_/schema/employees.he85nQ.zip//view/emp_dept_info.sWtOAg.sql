create definer = root@localhost view emp_dept_info as
select `de`.`emp_no`    AS `emp_no`,
       `de`.`dept_no`   AS `dept_no`,
       `dp`.`dept_name` AS `dept_name`,
       `de`.`from_date` AS `from_date`,
       `de`.`to_date`   AS `to_date`
from (`employees`.`dept_emp` `de` join `employees`.`departments` `dp` on ((`de`.`dept_no` = `dp`.`dept_no`)));

