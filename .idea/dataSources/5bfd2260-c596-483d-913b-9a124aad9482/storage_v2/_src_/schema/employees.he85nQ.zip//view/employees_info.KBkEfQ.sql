create definer = root@localhost view employees_info as
select `e`.`emp_no`     AS `emp_no`,
       `e`.`birth_date` AS `birth_date`,
       `e`.`first_name` AS `first_name`,
       `e`.`last_name`  AS `last_name`,
       `e`.`gender`     AS `gender`,
       `e`.`hire_date`  AS `hire_date`,
       `t`.`title`      AS `title`,
       `t`.`from_date`  AS `t_frome`,
       `t`.`to_date`    AS `t_to`,
       `s`.`salary`     AS `salary`,
       `s`.`from_date`  AS `s_from`,
       `s`.`to_date`    AS `s_to`
from ((`employees`.`employees` `e` join `employees`.`salaries` `s`
       on ((`e`.`emp_no` = `s`.`emp_no`))) join `employees`.`titles` `t` on ((`s`.`emp_no` = `t`.`emp_no`)));

